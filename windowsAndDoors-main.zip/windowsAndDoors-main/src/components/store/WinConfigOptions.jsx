import { createSlice } from "@reduxjs/toolkit";

const configOptions = [
    {
        title: "material",
        options: [
            {
                name: "uPVC",
                image: "https://www.windows24.com/cdn-cgi/image/quality=90,format=auto/img/global/attributevalue/ideal-4000.jpg",
                price: "30",
                selected: false,
            },
        ],
    },
    {
        title: "profile company",
        options: [
            {
                name: "kompen",
                image: "https://www.virtualfairs365.com/wp-content/uploads/2021/05/kompen.jpg",
                price: "30",
                selected: false,
            },
            {
                name: "salamander",
                image: "https://a.storyblok.com/f/227108/716x716/e35f1efa8c/brand_swds.jpg/m/2400x0",
                price: "40",
                selected: false,
            },
            {
                name: "nilewindow",
                image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3QgwlGScukqpL_8726CM-9T4OTrqhmT3vCOtDndD0iQ&s",
                price: "20",
                selected: false,
            },
        ],
    },
    {
        title: "opening system",
        options: [
            {
                name: "sliding window",
                image: "https://easi-serv.com/wp-content/uploads/2016/07/Dry-Glazing-Original-1-1.jpg",
                price: "45",
                selected: false,
            },
            {
                name: "casement window",
                image: "https://5.imimg.com/data5/IO/GR/MY-52834025/upvc-french-casement-window-500x500-500x500.jpg",
                price: "37",
                selected: false,
            },
        ],
    },
    {
        title: "frame profile",
        options: [
            {
                name: "with renovation",
                image: "https://www.grahamwindows.com/wp-content/uploads/fi_GT6700_awn_L.jpg",
                price: "25",
                selected: false,
            },
            {
                name: "without renovation",
                image: "https://www.grahamwindows.com/wp-content/uploads/fi_GT6700_awn_L.jpg",
                price: "17",
                selected: false,
            },
        ],
    },
    {
        title: "sash",
        options: [
            {
                name: "window sash",
                image: "https://sashwindows.london/wp-content/uploads/2019/02/Sash-Diagram-272x300.jpg",
                price: "24",
                selected: false,
            },
            {
                name: "door sash",
                image: "https://i0.wp.com/realcarriagedoors.com/wp-content/uploads/2018/10/custom-diagram-.png?resize=1200%2C937&ssl=1",
                price: "22",
                selected: false,
            },
        ],
    },
    {
        title: "shape",
        options: [
            {
                name: "rectangle",
                image: "https://blackbadgedoors.com/cdn/shop/files/ExtraV5.1-001-May11.jpg?v=1684407833&width=3000",
                price: "15",
                selected: false,
            },
            {
                name: "arch",
                image: "https://www.infinitywindows.com/images/infinity/windows/round-top/styles/RT-Half-Round-Above-Springline.webp",
                price: "20",
                selected: false,
            },
        ],
    },
    {
        title: "opening layout",
        options: [
            {
                name: "turn left",
                image: "https://eurovistadoors.com/wp-content/uploads/2022/01/Tilt-and-turn-left.png",
                price: "21",
                selected: false,
            },
            {
                name: "turn right",
                image: "https://eurovistadoors.com/wp-content/uploads/2022/01/Tilt-and-turn-left.png",
                price: "21",
                selected: false,
            },
            {
                name: "fixed",
                image: "https://glassandaluminum.topworksbuilders.ph/wp-content/uploads/2020/02/fixed-windows.jpg",
                price: "19",
                selected: false,
            },
            {
                name: "turn and tilt",
                image: "https://eurovistadoors.com/wp-content/uploads/2022/01/Tilt-and-turn-left.png",
                price: "35",
                selected: false,
            },
        ],
    },
    {
        title: "color",
        options: [
            {
                name: "white",
                image: "https://www.windows24.com/cdn-cgi/image/quality=90,format=auto/img/global/attributevalue/weiss.jpg",
                price: "0",
                selected: false,
            },
            {
                name: "mahogany",
                image: "https://www.windows24.com/cdn-cgi/image/quality=90,format=auto/img/global/attributevalue/standarddekor-dekor-mahagoni.jpg",
                price: "0",
                selected: false,
            },
            {
                name: "golden oak",
                image: "https://www.windows24.com/cdn-cgi/image/quality=90,format=auto/img/global/attributevalue/standarddekor-golden-oak.jpg",
                price: "0",
                selected: false,
            },
            {
                name: "welnut",
                image: "https://www.windows24.com/cdn-cgi/image/quality=90,format=auto/img/global/attributevalue/standarddekor-dekor-nussbaum.jpg",
                price: "0",
                selected: false,
            },
            {
                name: "gray",
                image: "https://htmlcolorcodes.com/assets/images/colors/steel-gray-color-solid-background-1920x1080.png",
                price: "0",
                selected: false,
            },
        ],
    },
];

const winOptionsSlice = createSlice({
    name: "winConfigOptions",
    initialState: configOptions,
    reducers: {
        selectOption(state, action) {
            const { option, index } = action.payload;
            state[index].options.forEach((opt, i) => {
                if (opt.name === option) {
                    state[index].options[i].selected = true;
                } else {
                    state[index].options[i].selected = false;
                }
            });
        },
    },
});

export default winOptionsSlice;
const winSelectActions = winOptionsSlice.actions;
export {winSelectActions} 