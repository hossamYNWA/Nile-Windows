import { createSlice } from "@reduxjs/toolkit";
const windowsInitState = [
    { material: null },
    { profile_company: null },
    { opening_system: null },
    { frame_profile: null },
    { sash: null },
    { shape: null },
    { opening_layout: null },
    { color: null },
    { glass_type: null, glass_specification: null, glass_thickness: null },
    { height: null, width: null, pieces: null },
];

const windowsSlice = createSlice({
    name: "selectedWinConfigs",
    initialState: windowsInitState,
    reducers: {
        addConfig(state, action) {
            console.log(action.payload);
            const { option, index } = action.payload;
            const keyOfSelectedOption = Object.keys(state[index])[0];
            console.log(keyOfSelectedOption);
            state[index][keyOfSelectedOption] = option;
        },
        addRadioConfig(state, action) {
            console.log(action.payload);
            console.log("helooooo")
            const { configName, selectedOption } = action.payload;
            state[8][configName] = selectedOption;
        },
        addInputData(state, action) {
            const { keyName, val } = action.payload;
            state[9][keyName] = val;
        },
    },
});

const addWinConfig = windowsSlice.actions;
export default windowsSlice;
export { addWinConfig };
