import classes from "./ConfigBody.module.css";
import OptionCard from "./OptionCard.jsx";
const ConfigBody = ({ options,index }) => {
    const content = options.map((option, i) => {
        return (
                <OptionCard option={option} key={i} index={index} />
        );
    });
    return <div className={classes.body}>{content}</div>;
};

export default ConfigBody;
