import CartContent from "../components/cart/CartContent.jsx";

function Cart(){
    return(
        <CartContent/>
    )
}

export default Cart