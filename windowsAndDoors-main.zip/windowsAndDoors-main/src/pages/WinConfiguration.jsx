import Config from "../components/configSection/Config.jsx";
import { useEffect } from "react";

async function fetchDataFromUrl(url) {
    try {
        const res = await fetch(url);
        const data = await res.json();
        const strigifiedData = JSON.stringify(data);
        // Process the retrieved data here
        console.log("data is:  " + strigifiedData);
    } catch (error) {
        // Handle any errors here
        console.error("Error:", error);
    }
}

function WinConfiguration() {
    useEffect(() => {
        fetchDataFromUrl("http://localhost:8000/api/v1/Sash");
    }, []);
    return <Config />;
}

export default WinConfiguration;
